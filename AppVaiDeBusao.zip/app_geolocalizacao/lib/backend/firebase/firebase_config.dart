import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';

Future initFirebase() async {
  if (kIsWeb) {
    await Firebase.initializeApp(
        options: const FirebaseOptions(
            apiKey: "AIzaSyACNeWS9IxxIxOb6ATISokxF_P80LU17jw",
            authDomain: "appgeolocalizacao-c9412.firebaseapp.com",
            projectId: "appgeolocalizacao-c9412",
            storageBucket: "appgeolocalizacao-c9412.appspot.com",
            messagingSenderId: "962830007099",
            appId: "1:962830007099:web:0675363ea99f477986551e"));
  } else {
    await Firebase.initializeApp();
  }
}
